package com.uni.battleships;

/**
 * Created with IntelliJ IDEA.
 * User: dogmaan
 * Date: 08/06/12
 * Time: 06:19
 * To change this template use File | Settings | File Templates.
 */
public enum PlayerMode
{
    PLAYER_VS_PLAYER, PLAYER_VS_CPU, CPU_VS_CPU, INVALID
}
