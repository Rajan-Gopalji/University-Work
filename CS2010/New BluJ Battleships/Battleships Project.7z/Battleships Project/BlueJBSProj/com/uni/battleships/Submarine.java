package com.uni.battleships;

import java.awt.*;

/**
 * User: dogmaan
 * Date: 08/06/12
 * Time: 03:37
 */
public class Submarine extends Ship
{
    public Submarine()
    {
        setShipSymbol('S');
        setDimensions(new Dimension(1, 1));
    }
}
