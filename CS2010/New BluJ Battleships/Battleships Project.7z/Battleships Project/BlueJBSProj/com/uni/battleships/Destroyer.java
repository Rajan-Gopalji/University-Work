package com.uni.battleships;

import java.awt.*;

/**
 * User: dogmaan
 * Date: 08/06/12
 * Time: 03:37
 */
public class Destroyer extends Ship
{
    public Destroyer()
    {
        setShipSymbol('D');
        setDimensions(new Dimension(2, 1));
    }
}
