package com.uni.battleships;

/**
 * User: dogmaan
 * Date: 08/06/12
 * Time: 06:28
 */
public enum ShipType
{
    BATTLESHIP, CRUISER, DESTROYER, SUBMARINE
}
