package com.uni.battleships;

/**
 * User: dogmaan
 * Date: 07/06/12
 * Time: 17:20
 */

public enum Owner
{
    PLAYER1, PLAYER2
}
