package com.uni.battleships;

import java.awt.*;

/**
 * User: dogmaan
 * Date: 06/06/12
 * Time: 07:33
 */

public class Battleship extends Ship
{

    public Battleship()
    {
        setShipSymbol('B');
        setDimensions(new Dimension(4, 1));
    }


}
