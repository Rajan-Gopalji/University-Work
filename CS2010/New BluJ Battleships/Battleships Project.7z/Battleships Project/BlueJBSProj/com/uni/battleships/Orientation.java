package com.uni.battleships;

/**
 * User: dogmaan
 * Date: 01/07/12
 * Time: 16:21
 */
public enum Orientation
{
    HORIZONTAL, VERTICAL
}
