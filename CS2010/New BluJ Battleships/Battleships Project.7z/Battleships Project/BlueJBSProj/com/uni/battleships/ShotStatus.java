package com.uni.battleships;

/**
 * User: dogmaan
 * Date: 06/06/12
 * Time: 16:41
 */
public enum ShotStatus
{

    HIT, MISS,
}
