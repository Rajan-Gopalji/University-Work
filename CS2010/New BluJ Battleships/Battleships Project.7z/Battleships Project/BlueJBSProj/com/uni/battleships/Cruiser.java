package com.uni.battleships;

import java.awt.*;

/**
 * User: dogmaan
 * Date: 08/06/12
 * Time: 03:37
 */
public class Cruiser extends Ship
{
    public Cruiser()
    {
        setShipSymbol('C');
        setDimensions(new Dimension(3, 1));
    }
}
